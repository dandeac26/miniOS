#ifndef _LOGGING_H_
#define _LOGGING_H_

#include "main.h"

void InitLogging();

void Log(char * Message);


#endif // _LOGGING_H_